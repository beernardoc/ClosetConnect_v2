export interface Comment {
  id: number;
  text: string;
  rating: number;
  user_id: number;
  seller_id: number;
  image: string;
  name: string;
  alter: boolean;
}
